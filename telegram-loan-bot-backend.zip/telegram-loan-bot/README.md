# Telegram Loan Application Demo Backend

This is a simple Node.js backend for a Telegram loan-application demo.

## Safety

Do not collect or store EcoCash PINs, passwords, OTPs, or other secret authentication credentials.

## Local setup

1. Install Node.js 18+.
2. Copy `.env.example` to `.env`.
3. Put your BotFather token in `.env`.
4. Run:

```bash
npm install
npm start
```

The server listens on port 3000 by default.

## Hosting

Deploy this project to a Node.js-capable host such as Render. Add `TELEGRAM_BOT_TOKEN` as an environment variable in the host's settings.

After deployment, set the Telegram webhook to:

`https://YOUR-DOMAIN/telegram/webhook`

Using Telegram's Bot API, call `setWebhook` with that URL. Keep the bot token private.

## Demo behavior

Send `/start` or `/apply` to the bot. It asks for:

- Full name
- Phone number
- Loan amount
- Loan purpose
- Repayment period

Completed applications are printed to the server log for this demo. They are not stored in a permanent database.
