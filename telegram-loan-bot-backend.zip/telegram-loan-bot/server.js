import express from "express";
import "dotenv/config";

const app = express();
app.use(express.json());

const token = process.env.TELEGRAM_BOT_TOKEN;
const port = process.env.PORT || 3000;

if (!token) {
  console.error("Missing TELEGRAM_BOT_TOKEN environment variable.");
  process.exit(1);
}

const api = `https://api.telegram.org/bot${token}`;
const sessions = new Map();

async function sendMessage(chatId, text, options = {}) {
  const response = await fetch(`${api}/sendMessage`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ chat_id: chatId, text, ...options })
  });
  if (!response.ok) {
    console.error("Telegram error:", await response.text());
  }
}

function startApplication(chatId) {
  sessions.set(chatId, { step: "name", application: {} });
  return sendMessage(
    chatId,
    "Loan Application Demo\n\nLet's begin.\n\n1/5 Please enter your full name."
  );
}

async function handleMessage(message) {
  const chatId = message.chat?.id;
  const text = (message.text || "").trim();

  if (!chatId) return;

  if (text === "/start" || text === "/apply") {
    await startApplication(chatId);
    return;
  }

  if (text === "/cancel") {
    sessions.delete(chatId);
    await sendMessage(chatId, "Application cancelled. Send /apply to start again.");
    return;
  }

  const session = sessions.get(chatId);

  if (!session) {
    await sendMessage(chatId, "Welcome. Send /apply to start a loan application demo.");
    return;
  }

  if (session.step === "name") {
    session.application.name = text;
    session.step = "phone";
    await sendMessage(chatId, "2/5 Please enter your phone number.");
  } else if (session.step === "phone") {
    session.application.phone = text;
    session.step = "amount";
    await sendMessage(chatId, "3/5 What loan amount are you requesting?");
  } else if (session.step === "amount") {
    session.application.amount = text;
    session.step = "purpose";
    await sendMessage(chatId, "4/5 What is the purpose of the loan?");
  } else if (session.step === "purpose") {
    session.application.purpose = text;
    session.step = "period";
    await sendMessage(chatId, "5/5 What repayment period would you prefer?");
  } else if (session.step === "period") {
    session.application.period = text;

    // Demo only: the application is held in memory.
    console.log("NEW DEMO APPLICATION:", {
      telegramUserId: chatId,
      ...session.application
    });

    await sendMessage(
      chatId,
      `Application received for this demo.\n\n` +
      `Name: ${session.application.name}\n` +
      `Phone: ${session.application.phone}\n` +
      `Amount: ${session.application.amount}\n` +
      `Purpose: ${session.application.purpose}\n` +
      `Repayment period: ${session.application.period}\n\n` +
      `This demo does not make a lending decision.`
    );

    sessions.delete(chatId);
  }
}

app.get("/", (_req, res) => {
  res.send("Telegram loan application demo backend is running.");
});

app.post("/telegram/webhook", async (req, res) => {
  try {
    await handleMessage(req.body);
    res.sendStatus(200);
  } catch (error) {
    console.error(error);
    res.sendStatus(500);
  }
});

app.listen(port, () => {
  console.log(`Server listening on port ${port}`);
});
