const http = require("http");

const PORT = process.env.PORT || 3000;

const server = http.createServer((req, res) => {
  res.setHeader("Content-Type", "application/json");

  if (req.method === "GET" && req.url === "/") {
    res.statusCode = 200;
    return res.end(JSON.stringify({
      status: "ok",
      message: "Telegram Loan Bot backend is running"
    }));
  }

  if (req.method === "POST" && req.url === "/api/applications") {
    let body = "";

    req.on("data", chunk => {
      body += chunk;
    });

    req.on("end", () => {
      try {
        const data = body ? JSON.parse(body) : {};
        const { fullName, phone, amount, purpose } = data;

        if (!fullName || !phone || !amount || !purpose) {
          res.statusCode = 400;
          return res.end(JSON.stringify({
            error: "fullName, phone, amount, and purpose are required"
          }));
        }

        res.statusCode = 201;
        return res.end(JSON.stringify({
          success: true,
          message: "Application received",
          application: { fullName, phone, amount, purpose }
        }));
      } catch {
        res.statusCode = 400;
        return res.end(JSON.stringify({ error: "Invalid JSON" }));
      }
    });
    return;
  }

  res.statusCode = 404;
  res.end(JSON.stringify({ error: "Not found" }));
});

server.listen(PORT, "0.0.0.0", () => {
  console.log(`Server is running on port ${PORT}`);
});
