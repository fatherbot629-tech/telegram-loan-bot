const express = require("express");

const app = express();
app.use(express.json());

app.get("/", (req, res) => {
  res.json({ ok: true, message: "Loan application demo backend is running." });
});

app.post("/api/applications", (req, res) => {
  const { fullName, phone, amount, purpose } = req.body || {};

  if (!fullName || !phone || !amount || !purpose) {
    return res.status(400).json({
      ok: false,
      message: "Full name, phone, amount and purpose are required."
    });
  }

  console.log("Demo application received:", {
    fullName, phone, amount, purpose
  });

  res.json({ ok: true, message: "Application received for demo processing." });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, "0.0.0.0", () => {
  console.log(`Server listening on ${PORT}`);
});
