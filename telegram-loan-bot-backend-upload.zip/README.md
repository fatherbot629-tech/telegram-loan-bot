# Telegram Loan Bot Backend — Demo

Simple demo backend for a Telegram loan-application project.

Important: this demo does not collect passwords, PINs, OTPs, card credentials, or other authentication secrets.
